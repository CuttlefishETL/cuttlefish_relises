print("A: parsed")
local parsed = json.parse(body)

print("B: DOCS")
local arr = parsed.DOCS

print("C: compile extractor")
-- Схема извлечения ссылок. Компилируется ОДИН РАЗ на весь скрипт.
-- Пути указывай под свою структуру DOC_BODY.
local extractor = json.compile_paths({
    -- Шапка (только GUID-поля)
    "r1", "r2", "r3", "r4", "r5", "r6", "r7",

    -- Табличная часть t1 (товары)
    "t1[].r1", "t1[].r2", "t1[].r3", "t1[].r4",

    -- Табличная часть t2
    "t2[].r3",

    -- Табличная часть t3
    "t3[].r2", "t3[].r3", "t3[].r4",
})

print("D: redb")
local redb = get_connector("redb")

print("E: build batch, n=" .. #arr)
local batch = {}
local total_uids = 0

for i = 1, #arr do
    local doc = arr[i]

    -- Шапка документа
    local k1 = doc.DOC_TYPE:as_string()
    local k2 = doc.DOC_ID:as_string()

    -- Плоский сбор всех UID одним FFI-вызовом.
    local body = doc.DOC_BODY
    --local uids = extractor:flat(body, true) -- только уникальные
    local uids = extractor:flat(body, true) -- все
    total_uids = total_uids + #uids

    -- Отладка: посмотрим, что нашли на первых двух документах.
    --[[
    if i <= 2 then
        print(string.format(
            "  doc[%d] key=%s:%s, uids=%d",
            i, k1, k2, #uids
        ))
        for j = 1, #uids do
            print(string.format("    uid[%d] = %s", j, tostring(uids[j])))
        end
    end
]]--
    -- Структурированный вариант (если нужен доступ по имени пути).
    -- Раскомментируй, если используешь.
    -- local refs = extractor:apply(body)
    -- refs["Контрагент.UID"]              → "uid-..." (скаляр)
    -- refs["Товары[].Номенклатура.UID"]   → { "u1", "u2", ... } (массив)

    batch[i] = {
        key   = k1 .. ":" .. k2,
        value = body,
    }
end

print(string.format("F: batch_set, docs=%d, uids=%d", #batch, total_uids))
redb:batch_set("docs", batch)

print("G: done")

return {
    status = 200,
    headers = {
        ["Content-Type"] = "application/json"
    },
    body = "OK"
}