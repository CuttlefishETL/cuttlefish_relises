local json = require("json")   -- если модуль доступен
local req = json.decode(document)

return {
    status = 200,
    headers = { ["Content-Type"] = "application/json" },
    body = json.encode({
        method = req.method,
        path = req.path,
        headers = req.headers,
        query = req.query,
        body = req.body
    })
}