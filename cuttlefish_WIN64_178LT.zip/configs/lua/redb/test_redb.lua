-- test_redb.lua
local redb = get_connector("redb")
if not redb then
    error("REDB connector 'redb' not found")
end

print("=== REDB Plugin Test (in-memory) ===")

-- 1. SET / GET
print("\n1. set/get")
redb:set("users", "alice", { name = "Alice", age = 30 })

local get_res = redb:get("users", "alice")
if get_res then
    local rows = get_res:toTable()
    if #rows > 0 then
        local alice = rows[1]
        print("  GET alice: name=" .. alice.value.name .. ", age=" .. alice.value.age)
    else
        print("  GET alice: not found")
    end
else
    print("  GET alice: failed")
end

-- 2. BATCH_SET
print("\n2. batch_set")
local batch = {
    { key = "bob",     value = { name = "Bob",     age = 25 } },
    { key = "charlie", value = { name = "Charlie", age = 35 } }
}
local batch_res = redb:batch_set("users", batch)
if batch_res then
    local info = batch_res:toTable()
    print("  inserted rows: " .. (info.affected_rows or 0))
end

-- 3. SCAN
print("\n3. scan")
local scan_res = redb:scan("users")
if scan_res then
    local rows = scan_res:toTable()
    print("  total rows: " .. #rows)
    for i, row in ipairs(rows) do
        print("    " .. i .. ". key=" .. row.key .. ", name=" .. row.value.name)
    end
end

-- 4. GET_BATCH (новое)
print("\n4. get_batch")
local keys = { "alice", "bob", "ghost", "charlie" }
local gb_res = redb:get_batch("users", keys)
if gb_res then
    local rows = gb_res:toTable()
    print("  requested " .. #keys .. " keys, found " .. #rows .. " records")
    for i, row in ipairs(rows) do
        print("    " .. i .. ". key=" .. row.key .. ", name=" .. row.value.name)
    end
else
    print("  get_batch failed")
end

-- 5. DELETE
print("\n5. delete")
local del_res = redb:delete("users", "bob")
if del_res then
    local info = del_res:toTable()
    print("  deleted: " .. (info.deleted and "yes" or "no"))
end

-- 6. TRANSACTION
print("\n6. transaction")
redb:begin()
redb:set("users", "diana", { name = "Diana", age = 28 })
redb:commit()

local diana_res = redb:get("users", "diana")
if diana_res then
    local rows = diana_res:toTable()
    if #rows > 0 then
        print("  transaction committed, Diana exists")
    end
end

redb:begin()
redb:set("users", "eve", { name = "Eve", age = 22 })
redb:rollback()

local eve_res = redb:get("users", "eve")
if eve_res then
    local rows = eve_res:toTable()
    if #rows == 0 then
        print("  rollback succeeded, Eve not present")
    else
        print("  rollback failed, Eve found")
    end
else
    print("  rollback succeeded, Eve not present")
end

print("\n=== Test completed ===")