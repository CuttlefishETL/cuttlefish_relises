-- bench_redb.lua
-- Бенчмарк производительности REDB-плагина (in-memory)

local N = 1000  -- Количество записей для теста

local redb = get_connector("redb")
if not redb then
    error("Connector 'redb' not found")
end

print("=== REDB Benchmark (N = " .. N .. ") ===")
print("")

-- Вспомогательная функция для замера времени
local function measure_time(fn)
    local start = os.clock()
    fn()
    return os.clock() - start
end

-- Генерация тестовых данных
local function generate_data(n)
    local data = {}
    for i = 1, n do
        local key = "key_" .. i
        local value = {
            id = i,
            name = "User " .. i,
            age = math.random(18, 80),
            active = i % 2 == 0,
            created = os.time() - i * 86400
        }
        table.insert(data, { key = key, value = value })
    end
    return data
end

local test_data = generate_data(N)

-- 1. Одиночная вставка (set)
print("1. Single inserts (set)")
local time_set = measure_time(function()
    for _, item in ipairs(test_data) do
        redb:set("bench_users", item.key, item.value)
    end
end)
print("   Time: " .. string.format("%.4f", time_set) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_set))
print("")

-- 1b. Одиночная вставка в транзакции
print("1b. Single inserts with transaction")
local time_txn = measure_time(function()
    redb:begin()
    for _, item in ipairs(test_data) do
        redb:set("bench_users_txn", item.key, item.value)
    end
    redb:commit()
end)
print("   Time: " .. string.format("%.4f", time_txn) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_txn))
print("")

-- 2. Пакетная вставка (batch_set)
print("2. Batch inserts (batch_set)")
local time_batch = measure_time(function()
    local pairs_arr = {}
    for _, item in ipairs(test_data) do
        table.insert(pairs_arr, { key = item.key, value = item.value })
    end
    redb:batch_set("bench_users_batch", pairs_arr)
end)
print("   Time: " .. string.format("%.4f", time_batch) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_batch))
print("")

-- 3. Одиночное чтение (get)
print("3. Single reads (get)")
local time_get = measure_time(function()
    for _, item in ipairs(test_data) do
        local res = redb:get("bench_users", item.key)
        if res then
            local rows = res:toTable()
            -- чтение уже произошло
        end
    end
end)
print("   Time: " .. string.format("%.4f", time_get) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_get))
print("")

-- 3b. Пакетное чтение (get_batch) — новое
print("3b. Batch reads (get_batch)")
local all_keys = {}
for _, item in ipairs(test_data) do
    table.insert(all_keys, item.key)
end
local time_get_batch = measure_time(function()
    local res = redb:get_batch("bench_users", all_keys)
    if res then
        local rows = res:toTable()
        -- rows уже загружены в память
    end
end)
print("   Time: " .. string.format("%.4f", time_get_batch) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_get_batch))
print("")

-- 4. Сканирование всех записей (scan)
print("4. Full scan (scan)")
local time_scan = measure_time(function()
    local res = redb:scan("bench_users")
    if res then
        local rows = res:toTable()
        -- rows уже загружены в память
    end
end)
print("   Time: " .. string.format("%.4f", time_scan) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_scan))
print("")

-- 5. Удаление одиночных записей (delete)
print("5. Single deletes (delete)")
local time_delete = measure_time(function()
    for _, item in ipairs(test_data) do
        redb:delete("bench_users", item.key)
    end
end)
print("   Time: " .. string.format("%.4f", time_delete) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_delete))
print("")

-- 6. Очистка пакетной таблицы
print("6. Cleanup (delete all from batch table)")
local time_cleanup = measure_time(function()
    for _, item in ipairs(test_data) do
        redb:delete("bench_users_batch", item.key)
    end
end)
print("   Time: " .. string.format("%.4f", time_cleanup) .. " sec")
print("")

-- 7. Обновление одиночными set
print("7. Single updates (set with existing keys)")
local time_update = measure_time(function()
    for _, item in ipairs(test_data) do
        local new_value = {
            id = item.value.id,
            name = item.value.name,
            age = item.value.age + 1,
            active = item.value.active,
            created = item.value.created
        }
        redb:set("bench_users", item.key, new_value)
    end
end)
print("   Time: " .. string.format("%.4f", time_update) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_update))
print("")

-- 8. Пакетное обновление через batch_set
print("8. Batch updates (batch_set with existing keys)")
local time_batch_update = measure_time(function()
    local pairs_arr = {}
    for _, item in ipairs(test_data) do
        local new_value = {
            id = item.value.id,
            name = item.value.name,
            age = item.value.age + 1,
            active = item.value.active,
            created = item.value.created
        }
        table.insert(pairs_arr, { key = item.key, value = new_value })
    end
    redb:batch_set("bench_users_batch", pairs_arr)
end)
print("   Time: " .. string.format("%.4f", time_batch_update) .. " sec")
print("   Rows/sec: " .. string.format("%.0f", N / time_batch_update))
print("")

print("=== Benchmark finished ===")