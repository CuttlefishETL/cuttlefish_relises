local data, shared = ...

print("Выполнение задания по расписанию ")


-- Обязательно вернуть обе таблицы
return data, shared
