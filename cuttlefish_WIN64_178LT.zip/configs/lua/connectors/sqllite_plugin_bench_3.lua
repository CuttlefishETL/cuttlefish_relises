-- SQL Plugin Benchmark: comparing insert and read methods
print("SQL Plugin Benchmark")
local conn = get_connector("sqlite")
if not conn then error("Connector not found") end

conn:metric_set_tables({"users"}) 

local function create_table()
    conn:query("DROP TABLE IF EXISTS users", {})
    conn:query([[
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL
        )
    ]], {})
end

local num_rows = 1000

local function generate_data(n)
    local data = {}
    for i = 1, n do
        local name = "User" .. i
        local age = 20 + (i % 30)
        table.insert(data, {name, age})
    end
    return data
end

-- ======== 1. Single-row insert ========
print("\n=== Single-row insert ===")
create_table()
local start_insert = os.clock()
conn:query("BEGIN", {})
for i = 1, num_rows do
    local name = "User" .. i
    local age = 20 + (i % 30)
    conn:query("INSERT INTO users (name, age) VALUES (?, ?)", {name, age})
end
conn:query("COMMIT", {})
local insert_time = os.clock() - start_insert
print("Single-row insert time: " .. string.format("%.3f", insert_time) .. " sec")

-- Check row count
local res = conn:query("SELECT COUNT(*) as cnt FROM users", {})
local cnt = res:toTable()[1].cnt
print("Row count: " .. cnt)

-- ======== 2. Batch insert (insertBatch) ========
print("\n=== Batch insert (insertBatch) ===")
create_table()
local data = generate_data(num_rows)

local start_batch = os.clock()
local result = conn:insertBatch("INSERT INTO users (name, age) VALUES (?, ?)", data)
local batch_time = os.clock() - start_batch
print("Batch insert time: " .. string.format("%.3f", batch_time) .. " sec")

-- Check result
if result then
    local res_data = result:toTable()
    if res_data.error then
        print("Insert error: " .. res_data.error)
    else
        local affected = res_data.affected_rows
        local last_id = res_data.last_insert_id
        print("affected_rows: " .. (affected or "nil"))
        print("last_insert_id: " .. (last_id or "nil"))
    end
else
    print("Error: insertBatch result is nil")
end

-- Check row count
res = conn:query("SELECT COUNT(*) as cnt FROM users", {})
cnt = res:toTable()[1].cnt
print("Row count: " .. cnt)

-- Insert speedup
print("\n--- Insert comparison ---")
local speedup = insert_time / batch_time
print("Batch insert is " .. string.format("%.2f", speedup) .. " times faster than single-row")

-- ======== 3. Read benchmark ========
print("\n=== Read benchmark ===")
-- Repopulate table using batch insert for speed
create_table()
conn:insertBatch("INSERT INTO users (name, age) VALUES (?, ?)", data)

-- 3.1 toTable
print("\n[1] toTable...")
local start = os.clock()
res = conn:query("SELECT * FROM users", {})
local rows = res:toTable()
local toTable_time = os.clock() - start
print("toTable time: " .. string.format("%.3f", toTable_time) .. " sec, rows: " .. #rows)

-- 3.2 nextRow
print("\n[2] nextRow...")
start = os.clock()
res = conn:query("SELECT * FROM users", {})
local count_next = 0
while res:hasNext() do
    local row = res:nextRow()
    count_next = count_next + 1
end
local nextRow_time = os.clock() - start
print("nextRow time: " .. string.format("%.3f", nextRow_time) .. " sec, rows: " .. count_next)

-- 3.3 getData (old way)
print("\n[3] getData (old way)...")
start = os.clock()
res = conn:query("SELECT * FROM users", {})
local count_old = 0
while res:hasNext() do
    local row = res:next()
    local id = row:getData(0)
    local name = row:getData(1)
    local age = row:getData(2)
    count_old = count_old + 1
end
local old_time = os.clock() - start
print("getData time: " .. string.format("%.3f", old_time) .. " sec, rows: " .. count_old)

-- Read speedup
print("\n--- Read comparison ---")
print("toTable is " .. string.format("%.2f", old_time / toTable_time) .. " times faster than getData")
print("nextRow is " .. string.format("%.2f", old_time / nextRow_time) .. " times faster than getData")

print("\nBenchmark finished.")