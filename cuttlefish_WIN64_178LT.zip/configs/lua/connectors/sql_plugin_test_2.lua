-- Тестовый скрипт: создание таблицы, вставка данных, запрос
print("1: Получение коннектора")
local conn = get_connector("sqlite")
if not conn then error("Connector not found") end

print("2: Создание таблицы users (если не существует)")
local create_res = conn:query([[
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER NOT NULL
    )
]], {})
if create_res and create_res.error then
    print("CREATE TABLE failed: " , create_res.error)
end
print("Таблица создана/существует")

print("3: Вставка тестовых данных (если таблица пуста)")
-- Проверим, есть ли уже записи
local count_res = conn:query("SELECT COUNT(*) as cnt FROM users", {})
if count_res and count_res.error then
    print("SELECT COUNT failed: ", count_res.error)
end
-- Извлечём значение cnt
local cnt = 0
if count_res:hasNext() then
    local row = count_res:next()
    if row then
        cnt = row:getData(0) -- первая колонка
    end
end
if cnt == 0 then
    conn:query("BEGIN", {})
    --local insert_res = conn:query([[
      --  INSERT INTO users (name, age) VALUES 
            --('Alice', 25),
            --('Bob', 30),
            --('Charlie', 18),
            --('Diana', 22),
            --('Eve', 35)
    --]], {})

    insert_res = conn:query("INSERT INTO users (name, age) VALUES ('Alice', 25)", {})
    if insert_res and insert_res.error then
         print("INSERT failed: ", insert_res.error)
          conn:query("ROLLBACK", {})
    else
        print("Inserted rows:", insert_res:affectedRows())
        -- Фиксируем транзакцию
        conn:query("COMMIT", {})
    end
else
    print("Таблица уже содержит данные, пропускаем вставку")
end


print("4: Выполнение запроса SELECT * FROM users WHERE age > ?")
--local res = conn:query("SELECT * FROM users WHERE age > ?", {18})
local res = conn:query("SELECT * FROM users", {})
if res and res.error then
    print("SELECT failed: ", res.error)
end

print("5: Вывод результатов")
print("Колонок:", res:columns())
while res:hasNext() do
    local row = res:next()
    if row then
        for i = 0, res:columns() - 1 do
            local val = row:getData(i)
            print("col", i, "=", tostring(val))
        end
        print("---")
    end
end

print("Done")