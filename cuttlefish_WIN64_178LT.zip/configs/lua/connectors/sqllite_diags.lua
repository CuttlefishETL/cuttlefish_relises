print("SQL Plugin Diagnostic")
local conn = get_connector("sqlite")
if not conn then error("Connector not found") end

local function safe_query(sql, params)
    local res = conn:query(sql, params or {})
    if res == nil then
        print("ERROR: query returned nil: " .. sql)
        return nil
    end
    return res
end

print("\n[1] Creating table...")
safe_query("DROP TABLE IF EXISTS users")
local create = safe_query([[
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER NOT NULL
    )
]])
if create then print("Table created OK") end

print("\n[2] Inserting with BEGIN/COMMIT...")
safe_query("BEGIN")
local ok = true
for i = 1, 5 do
    local ins = safe_query("INSERT INTO users (name, age) VALUES (?, ?)", {"User"..i, 20+i})
    if not ins then ok = false break end
end
if ok then
    local comm = safe_query("COMMIT")
    if comm then print("COMMIT OK") end
end

print("\n[3] Counting rows using next()...")
local res = safe_query("SELECT * FROM users")
if res then
    local count = 0
    while res:hasNext() do
        res:next()
        count = count + 1
    end
    print("Rows found: " .. count)
end

print("\n[4] Testing insertBatch...")
local data = {}
for i = 1, 5 do table.insert(data, {"Batch"..i, 30+i}) end
local batch_res = conn:insertBatch("INSERT INTO users (name, age) VALUES (?, ?)", data)
if batch_res then
    local tbl = batch_res:toTable()
    if tbl.error then
        print("ERROR in insertBatch: " .. tbl.error)
    else
        print("affected_rows: " .. (tbl.affected_rows or "nil"))
        print("last_insert_id: " .. (tbl.last_insert_id or "nil"))
    end
else
    print("insertBatch returned nil")
end

print("\n[5] Final count...")
res = safe_query("SELECT COUNT(*) as cnt FROM users")
if res then
    local tbl = res:toTable()
    if tbl and #tbl > 0 then
        print("Count: " .. tbl[1].cnt)
    else
        print("Count: 0 (no rows)")
    end
end

print("\nDiagnostic complete.")