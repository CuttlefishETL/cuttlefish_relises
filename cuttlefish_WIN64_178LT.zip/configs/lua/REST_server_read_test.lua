print("A: read request")

-- Параметры запроса (body может быть пустым на GET).
local req = {}
if body ~= nil then
    local ok, parsed = pcall(json.parse, body)
    if ok and parsed ~= nil then
        req = parsed
    end
end

local req_type = (req.TYPE and req.TYPE:as_string()) or "РеализацияТоваровУслуг"
local req_keys = req.KEYS
local req_scan = req.SCAN and req.SCAN:as_boolean() or false
local req_start = req.START and req.START:as_string() or nil
local req_end = req.END and req.END:as_string() or nil

print("B: redb")
local redb = get_connector("redb")

-- ---- Читаем документы как Lua-таблицы ---------------------------------
local rows

if req_keys then
    -- ---- Режим 1: явный список ключей --------------------------------
    local keys = {}
    for i = 1, #req_keys do
        keys[i] = req_keys[i]:as_string()
    end
    print("C: get_batch, n=" .. #keys)
    rows = redb:get_batch("docs", keys):toTable()

else
    -- ---- Режим 2/3/4: скан -------------------------------------------
    local start_key, end_key
    local do_scan = false

    if req_type then
        start_key = req_type .. ":"
        end_key   = req_type .. ";"
        do_scan   = true
    elseif req_start or req_end then
        start_key = req_start
        end_key   = req_end
        do_scan   = true
    elseif req_scan then
        do_scan = true
    end

    if do_scan then
        print(string.format("C: scan [%s .. %s)",
            tostring(start_key), tostring(end_key)))
        rows = redb:scan("docs", start_key, end_key):toTable()
    else
        print("C: no filter, returning empty")
        rows = {}
    end
end

print("D: got rows=" .. #rows)

-- ---- Собираем JSON-массив через json.encode ---------------------------
local out = {}
for i = 1, #rows do
    out[i] = {
        key   = rows[i].key,
        value = rows[i].value,
    }
end

local body_out = json.encode(out, { sorted_keys = false })

print("E: done, body_bytes=" .. #body_out)

return {
    status = 200,
    headers = {
        ["Content-Type"] = "application/json"
    },
    body = body_out
}