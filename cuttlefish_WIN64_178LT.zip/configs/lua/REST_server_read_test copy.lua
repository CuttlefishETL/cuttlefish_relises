print("A: parsed")
local parsed = json.parse(body)

print("B: request")
-- Поддерживаем два режима:
--   1. Явный список ключей:  {"KEYS": ["Тип:UID", "Тип:UID", ...]}
--   2. Префиксный скан:      {"TYPE": "РеализацияТоваровУслуг"}
--   3. Полный скан:          {"SCAN": true}
--   4. Диапазон:             {"START": "...", "END": "..."}
local keys_arr = parsed.KEYS
local req_type = parsed.TYPE and parsed.TYPE:as_string() or nil
local req_scan = parsed.SCAN and parsed.SCAN:as_boolean() or false
local req_start = parsed.START and parsed.START:as_string() or nil
local req_end   = parsed.END   and parsed.END:as_string()   or nil

print("C: redb")
local redb = get_connector("redb")

local rows = {}

-- ---- Режим 1: явный список ключей --------------------------------------
if keys_arr then
    local keys = {}
    for i = 1, #keys_arr do
        keys[i] = keys_arr[i]:as_string()
    end

    print("D: get_batch, n=" .. #keys)
    local result = redb:get_batch("docs", keys)
    rows = result:toTable()

-- ---- Режим 2/3/4: скан диапазона ---------------------------------------
else
    local start_key, end_key

    if req_type then
        -- "РеализацияТоваровУслуг:" до "РеализацияТоваровУслуг;" —
        -- ';' это следующий ASCII после ':' (0x3A → 0x3B),
        -- поэтому такой диапазон покрывает все UID данного типа.
        start_key = req_type .. ":"
        end_key   = req_type .. ";"
    elseif req_start or req_end then
        start_key = req_start
        end_key   = req_end
    elseif req_scan then
        start_key = nil
        end_key   = nil
    else
        -- Ничего не передано — отдаём пустой результат.
        print("D: no filter, returning empty")
        rows = {}
    end

    if start_key ~= nil or end_key ~= nil or req_scan then
        print(string.format("D: scan [%s .. %s)",
            tostring(start_key), tostring(end_key)))
        local result = redb:scan("docs", start_key, end_key)
        rows = result:toTable()
    end
end

print("E: got rows=" .. #rows)

-- ---- Формируем ответ ---------------------------------------------------
-- rows[i].key   — строка "Тип:UID"
-- rows[i].value — распарсенное тело (Lua-таблица/скаляр)
local out = {}
for i = 1, #rows do
    local r = rows[i]
    out[i] = {
        key   = r.key,
        value = r.value,
    }
    -- Отладка первых двух записей.
    if i <= 2 then
        print(string.format("  row[%d] key=%s, value_type=%s",
            i, tostring(r.key), type(r.value)))
    end
end

print("F: done, out=" .. #out)

-- Возвращаем таблицу — ядро сериализует её в ответ REST-клиенту.
return {
    count = #out,
    docs  = out,
}